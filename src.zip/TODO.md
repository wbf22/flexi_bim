# FlexiBIM — Blender BIM Plugin TODO

Model freely in Blender, tag what things are, then auto-generate construction drawings.

## Locked Decisions
- **Audience:** General-purpose, but residential-first (design data model to generalize later)
- **Blender target:** 4.4 LTS (4.4.3 installed)
- **Drawing engine:** Geometry-based extraction (custom cut/slice + edge projection)
- **Metadata store:** Custom properties on objects

## Core Concept

Five separable systems:
1. **Geometry** — ordinary Blender meshes/objects (no rigid BIM authoring required)
2. **Semantic tags** — Wall, Slab, Beam, Column, Window, Door, Roof, Room, etc.
3. **Assemblies & materials** — layers, thicknesses, products, ratings, finishes
4. **Drawing generator** — plans, elevations, sections, dimensions, linework
5. **Document generator** — sheets, schedules, legends, title blocks, PDF/IFC/DXF

Three coexisting modeling levels:
- **L1 Visual** — untagged geometry, still appears in drawings
- **L2 Tagged** — object has a type; drives symbols, labels, schedules
- **L3 Constructible** — assemblies, framing, connections, details

## Done
- Addon boilerplate, repo structure, sidebar panel (registers cleanly on Blender 4.4.3)
- Packaged `flexi_bim.zip`; verified install-from-disk layout (package at zip root)
- Tagging system: tags on any object, costs, custom properties, quantity
  take-off, cost rollup/schedules (see `docs/TAGGING.md`)
- Single **tag registry**: every tag is defined once and referenced by objects,
  so editing a tag re-prices/re-labels every object using it (no local/library
  split, no per-object overrides)
- JSON v2 export/import (registry + object references), CSV schedule export
- Restored `tagging/measure.py` (had been overwritten by a copy of `exchange.py`)
- Root sidebar panel wired into `ui/panel.py`; orphaned `tagging/panel.py` removed
- All FlexiBIM panels verified to draw without error on Blender 4.4.3
- Drawing engine v1 (`drawings/`): `ViewSpec` selects by **axis + range + tag
  filter**; CUT (bisect) and PROJECT extraction; tag-coloured SVG export with
  leader notes. Verified headless (plan cut + filtered lighting plan)
- **Drawings** sidebar panel: create/edit/duplicate views (axis, direction,
  mode, cut level, range, tag picker, categories, scale, notes) and generate
  SVG to the output folder or export via a file dialog
- **Measurements** (Phase 4 v1): per-view **gap dimensions** between two
  selected objects — nearest-face distance measured in the view plane (Z view
  → XY, etc.), drawn on the `A-DIMS` layer with extension lines, 45° ticks and
  a length label. Verified headless

## Tooling
- [ ] Test suite + `tests/mockbpy`
- [ ] `scripts/blender_smoke.py`

## Phase 1 — Tagging
- [x] Define semantic type enum (wall, slab, beam, column, window, door, roof, room...)
- [x] Operator/UI to assign + edit type, name on selected objects
- [x] Store metadata in custom properties (survives remesh/re-model)
- [x] Property group + panel showing tags on active object
- [x] Tag inspector / list view of all tagged objects (per tag + per object rollup)
- [x] Cost per tag: flat rate or rate per measured quantity in project units
- [x] Arbitrary custom key/value properties per tag
- [x] Single project tag registry (define once, apply anywhere; editing a tag
      updates every object that uses it)
- [x] CSV cost schedule export, JSON tag import-export
- [ ] Auto-numbering (e.g. W-01, D-01, R-101) — needs an instance-level ID
      alongside the tag name
- [ ] Assign tags from the Outliner / right-click context menu
- [ ] Viewport colour overlay driven by tag colour

## Phase 2 — Orthographic Drawings
- [ ] Generate plan view (top-down ortho) from geometry
- [ ] Generate elevation views (4 sides)
- [ ] Generate section cuts (bisect/clip plane through model)
- [ ] Cut-line weight (thick) vs. elements behind cut (light)
- [x] Vector line output via custom geometry extraction (SVG; DXF next)
- [ ] View regenerate without destroying manual edits

## Phase 3 — Architectural Linework
- [ ] Line styles by type (cut, projection, hidden)
- [ ] Hatching for materials (poché for cut walls)
- [ ] Symbols for doors/windows/stairs/fixtures
- [ ] Level markers + elevation markers
- [ ] Clean SVG/DXF vector export

## Phase 4 — Dimensions & Annotations
- [x] Linear dimension tool (v1: manual gap between two objects, per view,
      associative — re-projects on regenerate; measured in the view plane)
- [ ] Dimension chains for layout (auto: features along the run axis + overall)
- [ ] Room name + area labels (boundary recognition)
- [ ] Text notes / leader annotations

## Phase 5 — Schedules
- [ ] Door schedule (from tagged doors)
- [ ] Window schedule (from tagged windows)
- [ ] Room finish schedule
- [ ] Wall type schedule
- [ ] Material quantities / takeoff
- [ ] Table → sheet rendering

## Phase 6 — Assemblies & Validation
- [ ] Assembly presets (exterior insulated wood frame, etc.)
- [ ] Layer stack editor (name, function, thickness) summing to overall thickness
- [ ] Structural flag, fire rating, insulation R-value, finishes
- [ ] Documentation preflight checker (report missing info)
- [ ] IDS/IFC-aligned metadata schema (design early, implement later)

## Phase 7 — Sheets & Export
- [ ] Sheet layout (viewport frames on a page)
- [ ] Multiple views per sheet with independent scales
- [ ] Title block, sheet numbers, legends, notes
- [ ] Reusable detail library (detail templates tied to assemblies)
- [ ] Export: PDF, DXF, and eventually IFC

## Cross-Cutting Constraints
- [ ] Generated drawings must refresh without overwriting manual annotations/sheet layouts
- [ ] Detail automation = template selection + user override (never silently invent connections)
